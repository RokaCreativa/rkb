/**
 * 🔧 SCRIPT DE MIGRACIÓN: Corrección de Campos de Ordenación
 * 
 * PROBLEMA: Los productos tienen valores en display_order (obsoleto) 
 * pero valores incorrectos en campos contextuales.
 * 
 * SOLUCIÓN: Migrar valores de display_order a campos contextuales correctos
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function migrateDisplayOrder() {
    console.log('🔄 Iniciando migración de campos display_order...');

    try {
        // 1. MIGRAR PRODUCTOS GLOBALES
        console.log('\n📍 PASO 1: Migrando productos globales...');

        // Productos que tienen category_id pero NO section_id (productos globales)
        const globalProducts = await prisma.products.findMany({
            where: {
                category_id: { not: null },
                section_id: null,
                deleted: false
            }
        });

        console.log(`Encontrados ${globalProducts.length} productos globales`);

        for (const product of globalProducts) {
            await prisma.products.update({
                where: { product_id: product.product_id },
                data: {
                    categories_display_order: product.display_order,
                    sections_display_order: null,
                    products_display_order: null,
                    // display_order: null // Comentado por ahora para no romper nada
                }
            });
            console.log(`✅ Producto global ${product.product_id} migrado: display_order ${product.display_order} → categories_display_order`);
        }

        // 2. MIGRAR PRODUCTOS LOCALES
        console.log('\n📍 PASO 2: Migrando productos locales...');

        // Productos que tienen category_id Y section_id (productos locales)
        const localProducts = await prisma.products.findMany({
            where: {
                category_id: { not: null },
                section_id: { not: null },
                deleted: false
            }
        });

        console.log(`Encontrados ${localProducts.length} productos locales`);

        for (const product of localProducts) {
            await prisma.products.update({
                where: { product_id: product.product_id },
                data: {
                    categories_display_order: null,
                    sections_display_order: product.display_order,
                    products_display_order: null,
                    // display_order: null // Comentado por ahora
                }
            });
            console.log(`✅ Producto local ${product.product_id} migrado: display_order ${product.display_order} → sections_display_order`);
        }

        // 3. MIGRAR PRODUCTOS NORMALES
        console.log('\n📍 PASO 3: Migrando productos normales...');

        // Productos que tienen section_id pero NO category_id (productos normales)
        const normalProducts = await prisma.products.findMany({
            where: {
                section_id: { not: null },
                category_id: null,
                deleted: false
            }
        });

        console.log(`Encontrados ${normalProducts.length} productos normales`);

        for (const product of normalProducts) {
            await prisma.products.update({
                where: { product_id: product.product_id },
                data: {
                    categories_display_order: null,
                    sections_display_order: null,
                    products_display_order: product.display_order,
                    // display_order: null // Comentado por ahora
                }
            });
            console.log(`✅ Producto normal ${product.product_id} migrado: display_order ${product.display_order} → products_display_order`);
        }

        // 4. MIGRAR SECCIONES
        console.log('\n📍 PASO 4: Migrando secciones...');

        const sections = await prisma.sections.findMany({
            where: { deleted: 0 }
        });

        console.log(`Encontradas ${sections.length} secciones`);

        for (const section of sections) {
            await prisma.sections.update({
                where: { section_id: section.section_id },
                data: {
                    sections_display_order: section.display_order,
                    // display_order: null // Comentado por ahora
                }
            });
            console.log(`✅ Sección ${section.section_id} migrada: display_order ${section.display_order} → sections_display_order`);
        }

        // 5. MIGRAR CATEGORÍAS
        console.log('\n📍 PASO 5: Migrando categorías...');

        const categories = await prisma.categories.findMany({
            where: { deleted: 0 }
        });

        console.log(`Encontradas ${categories.length} categorías`);

        for (const category of categories) {
            await prisma.categories.update({
                where: { category_id: category.category_id },
                data: {
                    categories_display_order: category.display_order,
                    // display_order: null // Comentado por ahora
                }
            });
            console.log(`✅ Categoría ${category.category_id} migrada: display_order ${category.display_order} → categories_display_order`);
        }

        console.log('\n🎉 MIGRACIÓN COMPLETADA EXITOSAMENTE');

    } catch (error) {
        console.error('❌ Error durante la migración:', error);
        throw error;
    } finally {
        await prisma.$disconnect();
    }
}

// Ejecutar migración
migrateDisplayOrder()
    .then(() => {
        console.log('✅ Script de migración terminado');
        process.exit(0);
    })
    .catch((error) => {
        console.error('❌ Script de migración falló:', error);
        process.exit(1);
    }); 