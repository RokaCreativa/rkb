/**
 * 🔧 SCRIPT DE MIGRACIÓN V2: Corrección de Campos de Ordenación (Arquitectura Real)
 * 
 * PROBLEMA: Los productos tienen valores en display_order (obsoleto) 
 * pero valores incorrectos en campos contextuales.
 * 
 * SOLUCIÓN: Migrar valores según la arquitectura REAL observada en logs
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function migrateDisplayOrderV2() {
    console.log('🔄 Iniciando migración V2 de campos display_order...');

    try {
        // 1. MIGRAR PRODUCTOS GLOBALES (Arquitectura Real)
        console.log('\n📍 PASO 1: Migrando productos globales (sección virtual)...');

        // Productos en secciones virtuales (is_virtual = true)
        const globalProducts = await prisma.products.findMany({
            where: {
                deleted: false,
                sections: {
                    is_virtual: true
                }
            },
            include: {
                sections: true
            }
        });

        console.log(`Encontrados ${globalProducts.length} productos globales en secciones virtuales`);

        for (const product of globalProducts) {
            await prisma.products.update({
                where: { product_id: product.product_id },
                data: {
                    categories_display_order: product.display_order,
                    sections_display_order: null,
                    products_display_order: null,
                }
            });
            console.log(`✅ Producto global ${product.product_id} (${product.name}) migrado: display_order ${product.display_order} → categories_display_order`);
        }

        // 2. MIGRAR PRODUCTOS LOCALES (Arquitectura Real)
        console.log('\n📍 PASO 2: Migrando productos locales (category_id sin section_id)...');

        // Productos que tienen category_id pero NO section_id (productos locales)
        const localProducts = await prisma.products.findMany({
            where: {
                category_id: { not: null },
                section_id: null,
                deleted: false
            }
        });

        console.log(`Encontrados ${localProducts.length} productos locales`);

        for (const product of localProducts) {
            await prisma.products.update({
                where: { product_id: product.product_id },
                data: {
                    categories_display_order: null,
                    sections_display_order: product.display_order,
                    products_display_order: null,
                }
            });
            console.log(`✅ Producto local ${product.product_id} (${product.name}) migrado: display_order ${product.display_order} → sections_display_order`);
        }

        // 3. PRODUCTOS NORMALES - Ya migrados correctamente en V1
        console.log('\n📍 PASO 3: Verificando productos normales (ya migrados)...');

        const normalProducts = await prisma.products.findMany({
            where: {
                section_id: { not: null },
                category_id: null,
                deleted: false,
                products_display_order: { not: null }
            }
        });

        console.log(`✅ ${normalProducts.length} productos normales ya migrados correctamente`);

        console.log('\n🎉 MIGRACIÓN V2 COMPLETADA EXITOSAMENTE');

    } catch (error) {
        console.error('❌ Error durante la migración V2:', error);
        throw error;
    } finally {
        await prisma.$disconnect();
    }
}

// Ejecutar migración V2
migrateDisplayOrderV2()
    .then(() => {
        console.log('✅ Script de migración V2 terminado');
        process.exit(0);
    })
    .catch((error) => {
        console.error('❌ Script de migración V2 falló:', error);
        process.exit(1);
    }); 